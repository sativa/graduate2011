﻿using System;
using System.Collections.Generic;

using System.Text;


    public class CBookInfo
    {
        public string itemName;
        public string itemDes;

        public CBookInfo(string name,string des)
        {
            itemName = name;
            itemDes = des;
        }
    }

