using UnityEngine;
using System.Collections;

public class Movie_All : MonoBehaviour {
	
	public MovieTexture  mov;

	// Use this for initialization
	void Start () {
	//mov.Start();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
