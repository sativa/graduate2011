using UnityEngine;
using System.Collections;

public class Control_Game : MonoBehaviour {

    static public bool bPause=false;

    static public bool bShowBook=false;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
