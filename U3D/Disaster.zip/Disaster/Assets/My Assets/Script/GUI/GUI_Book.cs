using UnityEngine;
using System.Collections;

public class GUI_Book : MonoBehaviour {

	public Rect pos;

    private CBookInfo[] info;
    private string desToShow;

	// Use this for initialization
	void Start () {
        info = new CBookInfo[5];
        info[0] = new CBookInfo("ϸĿ1","123");
        info[1] = new CBookInfo("ϸĿ2", "1234");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI()
	{
        if (Control_Game.bShowBook)
        {
            GUI.Window(0, pos, BookWindow, "�����ֲ�");



        }
	}

    void BookWindow(int id)
    {
        GUILayout.BeginVertical();

        GUILayout.Label("���ֵ�ע���");
        GUILayout.BeginHorizontal();

        // Item
        GUILayout.BeginVertical();
        foreach (CBookInfo bi in info)
        {
            if (bi == null)
                continue;
            if (GUILayout.Button(bi.itemName, GUILayout.MaxWidth(100)))
            {
                desToShow = bi.itemDes;
            }
        }
        GUILayout.EndVertical();

        // ϸĿ
        GUILayout.BeginVertical();
        GUILayout.Label(desToShow);

        GUILayout.EndVertical();

        GUILayout.EndHorizontal();

        GUILayout.FlexibleSpace();

        GUILayout.BeginHorizontal();
        GUILayout.Space(150);

        if (GUILayout.Button("�ر�"))
        {
            Control_Game.bPause = false;
            Control_Game.bShowBook = false;
        }
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();

    }
	
}
