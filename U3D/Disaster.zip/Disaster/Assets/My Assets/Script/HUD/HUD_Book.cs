using UnityEngine;
using System.Collections;

public class HUD_Book : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnMouseDown()
    {
        Control_Game.bPause = true;

        Control_Game.bShowBook = true;
    }
}
